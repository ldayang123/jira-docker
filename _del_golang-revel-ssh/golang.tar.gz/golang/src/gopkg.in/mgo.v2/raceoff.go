// +build !race

package mgo

const raceDetector = false
