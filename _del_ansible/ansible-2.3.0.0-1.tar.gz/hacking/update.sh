#!/bin/sh
git pull --rebase
git submodule update --init --recursive
